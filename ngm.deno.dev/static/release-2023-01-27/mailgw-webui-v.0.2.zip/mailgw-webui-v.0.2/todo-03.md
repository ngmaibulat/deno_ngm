### Deno

- Deno version
- Build as executable
- Run as Docker

### Test SMTP Relay:

- send simple email
- send customized message: from, to, cc, subject, body
- send with attachment
- custom smtp: sender, rcpt
- log smtp tests
