import { express } from "../adapter.js";

export function profile(req, res) {
    // res.send(form);
    res.render("util/notimpl", {});
}
