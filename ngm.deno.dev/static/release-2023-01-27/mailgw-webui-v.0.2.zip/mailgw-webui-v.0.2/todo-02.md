### Deployment

- Test on Ubuntu Server
- Script: deploy branch
- Deploy via ssh
- Deployment plan

### Docker

- docker build
- docker build via github actions
- run via kubernetes
- yaml files for kuber
- helm package
