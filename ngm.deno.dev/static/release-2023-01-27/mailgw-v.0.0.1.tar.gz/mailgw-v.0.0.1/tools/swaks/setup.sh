

wget http://untroubled.org/spam/2020.7z

sudo 7z x 2020.7z

sudo mv 2020 /var/2020

