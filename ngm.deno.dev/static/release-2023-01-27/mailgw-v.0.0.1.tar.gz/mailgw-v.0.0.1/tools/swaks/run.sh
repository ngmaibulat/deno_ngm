
bash send.sh ~/sa