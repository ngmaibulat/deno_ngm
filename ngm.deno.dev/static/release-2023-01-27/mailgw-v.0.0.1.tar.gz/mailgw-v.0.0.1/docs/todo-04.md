### Logger Service:

- typescript
- docs
- docker

### Log others:

- connection

### Hash lookups Service:

- separate repo
- typescript
- log requests
