import { Sequelize } from "../../src/adapter.js";
import config from "./config.mjs";

const sequelize = new Sequelize(
    config.database,
    config.username,
    config.password,
    config
);

try {
    await sequelize.authenticate();
    console.log("DB Connection: OK");
} catch (error) {
    console.error("DB Connection: FAIL");
    process.exit(1);
}

export default sequelize;
