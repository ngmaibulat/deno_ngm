### User Management

- User Management: CRUD
- Profile Page

- AD Auth
- Register/Approve mechanism
- Email Verification
- Reset password via email
- Roles: admin, logview, custom: view certain logs with filter
- View My Logs: sent to me
