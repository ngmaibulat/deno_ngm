import { zod as u } from "../adapter.js";

export const AuthInfo = u.object({
    email: u.string().min(4).max(20).email(),
    pass: u.string().min(8).max(20),
});
