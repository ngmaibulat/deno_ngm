export class CtrlRenameIt {
    async create(req, res) {}

    async createHandle(req, res) {}

    async edit(req, res) {}

    async editHandle(req, res) {}

    async delete(req, res) {}

    async deleteHandle(req, res) {}

    async details(req, res) {}

    async index(req, res) {}
}
