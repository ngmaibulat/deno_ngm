const express = require("express");
const router = express.Router();

const models = require("../../models");

module.exports = router;

router.post("/delivery", (req, res) => {
    models.Delivery.create(req.body);
    // console.log(req.body);
    res.send("OK: ");
});

router.post("/connection", (req, res) => {
    models.Connection.create(req.body);
    // console.log(req.body);
    res.send("OK");
});
