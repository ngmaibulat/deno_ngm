### Create Database

in mysql shell:

```sql
create database mailgw;
```

### Download/Unpack

```bash
wget https://ngm.deno.dev/release/logservice.tar.gz
tar -xvf logservice-version.tar.gz
sudo mv logservice-version /opt
```

### Env file

Make sure to have /opt/logservice.env
Example content:

```bash
NODE_ENV="production"
PORT=3000

DB_DRIVER="mysql"
DB_HOST="127.0.0.1"
DB_NAME="mailgw"
DB_USER="root"
DB_PASS="P@ssw0rd"
```

In version's folder, link .env to /opt/logservice.env

```bash
cd /opt/logservice-version
ln -s ../logservice.env .env
```

### Prepare Package

```bash
npm install
npx sequelize-cli db:migrate
npm run start
```

### Link to new Version

```bash
pm2 stop logservice # if we have pm2 task
rm -f /opt/logservice
sudo ln -s /opt/logservice-version /opt/logservice
sudo chown $USER:$USER . -R
pm2 start logservice # if we have pm2 task
```

### PM2 tasks

```bash
cd /opt/logservice
npm install -g pm2
pm2 start 'npm run start' -n logservice
pm2 save
pm2 ls
pm2 startup
```

### PM2 Daemon

Once you have run `pm2 startup`
and run the command it generated
PM2 should run automatically after reboot and should `resurrect` you services

Test that:

```bash
sudo reboot

#after rebbot
sudo systemctl status pm2-$USER
pm2 ls
```
