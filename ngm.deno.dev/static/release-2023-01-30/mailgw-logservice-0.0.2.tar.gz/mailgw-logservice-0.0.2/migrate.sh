
npx sequelize-cli db:migrate

# npx sequelize-cli migration:generate
