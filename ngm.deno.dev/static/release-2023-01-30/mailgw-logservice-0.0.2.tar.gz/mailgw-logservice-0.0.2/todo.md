### Test:

- make more detailed logging
- script to update node, pm2, pnpm

- update script: update-mail-gw <url>
- deploy script: deploy-mail-gw <url>
- rollback script: rollback-mail-gw <path-for-other-version>
- put deploy/update/rollback script to public repo
