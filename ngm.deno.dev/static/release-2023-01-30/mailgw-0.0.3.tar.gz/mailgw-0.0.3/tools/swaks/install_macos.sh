
brew install swaks

