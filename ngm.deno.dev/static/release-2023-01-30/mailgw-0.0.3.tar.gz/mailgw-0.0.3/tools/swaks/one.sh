./swaks --server 192.168.35.131  -f sender@example.com  -t user1@demo.local,user2@demo.local  -d /var/2020/01/1580341729.287491.60788.txt
